# MOONTON ACCOUNT CHECKER

Can only be run in python3

![IMG](ss.png)

## Install
```
pkg update && pkg upgrade
pkg install python git
pip install requests futures bs4
git clone https://github.com/dz-id/MoontonChecker
cd MoontonChecker
python moonton.py
```